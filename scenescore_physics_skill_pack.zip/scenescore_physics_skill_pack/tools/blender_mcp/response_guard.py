"""Conservative classification of MCP responses; not an animation-quality check."""
from __future__ import annotations

import json
from typing import Any

FAILURE_PREFIXES = ("error", "failed", "failure", "could not", "cannot ", "rejected", "no module named")


def classify_response(tool: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Detect transport and known content-level failures, including false isError flags.

    PASSED means no recognized call-level failure and expected content shape.
    It does NOT certify that executed code or a Blender scene is correct.
    """
    reasons: list[str] = []
    if payload.get("isError") is True:
        reasons.append("MCP isError is true")
    content = payload.get("content")
    if not isinstance(content, list) or not content:
        reasons.append("missing or empty tool content")
        content = []
    usable = False
    for block in content:
        if not isinstance(block, dict):
            reasons.append("invalid content block")
            continue
        if block.get("type") == "image":
            if block.get("data") or block.get("local_image"):
                usable = True
            else:
                reasons.append("image content lacks data or saved-image reference")
        elif block.get("type") == "text":
            text = block.get("text", "")
            if not isinstance(text, str) or not text.strip():
                reasons.append("empty or invalid text content")
                continue
            usable = True
            text = text.strip()
            if text.lower().startswith(FAILURE_PREFIXES):
                reasons.append(text[:500])
            try:
                obj = json.loads(text)
            except ValueError:
                obj = None
            if isinstance(obj, dict):
                if obj.get("error") or obj.get("success") is False or str(obj.get("status", "")).lower() in {"error", "failed", "failure", "rejected"}:
                    reasons.append("JSON content reports failure: " + text[:500])
        else:
            reasons.append("unrecognized content block requires review")
    structured = payload.get("structuredContent")
    if isinstance(structured, dict):
        if structured.get("error") or structured.get("success") is False or str(structured.get("status", "")).lower() in {"error", "failed", "failure", "rejected"}:
            reasons.append("structuredContent reports failure")
    if not usable:
        reasons.append("no usable recognized content")
    if tool == "get_viewport_screenshot" and not any(isinstance(b, dict) and b.get("type") == "image" and (b.get("data") or b.get("local_image")) for b in content):
        reasons.append("screenshot tool returned no image")
    return {"status": "FAILED" if reasons else "PASSED", "reasons": reasons,
            "scope": "MCP call result only; not production, physics or perception acceptance"}
