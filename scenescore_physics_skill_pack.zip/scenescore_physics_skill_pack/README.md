# SceneScore physics-aware animation skill and repair pack

Prepared 13 September 2026 against the uploaded `SceneScore-main(1).zip`.

## What this is

A repo-specific authoring skill, direct source/media audit, bounded implementation
brief, executable **design-intent linter**, and optional small **MCP client
error-reporting patch**. It is not a new Blender renderer, a repaired Bullet
backend, a trained model, or a rendered quality-matched animation. No existing
repository files were changed in the uploaded archive. Reference videos are not
redistributed here.

The original `blender_exemplar_search_kit` is still useful upstream. Its search
collector cannot fix scene generation and is not an animation skill. The repo
already contains that kit; do not import duplicate copies. Keep its curation and
reconstruction templates, use the new authoring skill for building, and resume
search only when a concrete capability gap calls for another reference.

## Files to use

- `.agents/skills/physics-aware-animation/SKILL.md`: new complementary skill;
  keep `blender-scene-export` intact.
- Skill `references/`: repo findings, supplied visual references, MCP loop.
- Skill `assets/scene-intent.example.json`: explicit unmeasured authoring target;
  **not a current renderer input** and not a solved scene.
- Skill `scripts/check_story_plan.py`: plan-only checks for event diversity,
  sparse spacing, continuous-support semantics and existing analytic scope.
- `docs/requests/blender-skill-repair.md`: next-task implementation brief.
- `tools/blender_mcp/response_guard.py` and test: conservative tool-result checks.
- `patches/mcp_client_result_handling.patch`: optional integration into the existing
  client; detects recognized text errors even when `isError` is false.
- `evidence/`: literal source excerpts, media probes and actual test logs.

## Installation without replacing your repo

Copy the new `.agents/skills/physics-aware-animation/` directory and the new task
brief into the matching locations of a working branch. Existing skills and
immutable documents stay unchanged. Agent discovery depends on the host's skill
support; explicitly ask the coding agent to read this SKILL.md when necessary.

For the optional MCP reliability patch, copy `response_guard.py` and its test to
`tools/blender_mcp/`, then run from the repo root:

```sh
git apply --check /path/to/this-pack/patches/mcp_client_result_handling.patch
git apply /path/to/this-pack/patches/mcp_client_result_handling.patch
python -m unittest discover -s tools/blender_mcp -p 'test_response_guard.py' -v
```

Review the diff before applying. A modified upstream client may need manual merge;
do not force the patch over newer edits. The patch intentionally makes a smoke
run fail overall when a status tool fails, even if inspection still succeeds.
The helper recognizes known failure shapes; it is not a universal semantic verifier.
It does not resolve machine-specific paths or fix the missing vendor module.

Run the new plan tests:

```sh
python -m unittest discover \
  -s .agents/skills/physics-aware-animation/tests -p 'test_*.py' -v
python .agents/skills/physics-aware-animation/scripts/check_story_plan.py \
  .agents/skills/physics-aware-animation/assets/scene-intent.example.json
```

The plan validator must never be substituted for actual physical-validation,
contact certificates, a full-motion review, music audition or human approval.

## Verification scope

101 existing scoped repo tests were executed successfully; see the log. New
helper tests and patch-application/compile checks are recorded separately in
`evidence/NEW_CHECKS.md`. Blender, a live MCP session and production assets were
not available here. No new simulation, preview/final render, physical repair or
end-to-end audiovisual acceptance is claimed.
