# Source evidence from the uploaded SceneScore archive

Inspected 2026-09-13. Line numbers below refer to the original files inside `SceneScore-main(1).zip`. Historical report claims are not fresh Blender reproductions.

## `.agents/skills/blender-scene-export/SKILL.md` lines 1–30

SHA-256: `fad50a836b671d4e976b28343f57cd9388761de4bb5ab763b002643c5cfcf282`

```text
1: ---
2: name: blender-scene-export
3: description: Generate or audit evaluated Blender scene sidecars for SceneScore phases 2B and integration.
4: ---
5: 
6: # blender-scene-export
7: 
8: Use only within the user's authorized phase. Read root AGENTS and VISION first; this skill cannot override either or expand authorization.
9: 
10: When not to use: Not for arbitrary-video reconstruction, music generation or rendering during Phase 0.
11: 
12: Required inputs: Verified BLENDER_BIN/version, immutable recipe seeds, canonical geometry contracts, seed and output budget.
13: 
14: Outputs: Scene bundle and hashes, evaluated object/pair sidecars, independent geometry QA, compact summary and render/visual QA status.
15: 
16: Workflow: Export evaluated world geometry and m² area; test s² scaling and translation/rotation invariance. Separate positive-gap near miss from contact and label heuristic provenance.
17: 
18: Executable checks: After Phase 1 run `make test-contracts`; run the owned Blender export/geometry CLI recorded by 2B on analytic touch, near miss and scaled-shape cases. Legacy CLI is `python -m modules.blender.batch`; the production CLI is `python -m modules.blender.production` with separate build, bake, replay, verify-replay, validate, export and render stages. Use installed Blender Python, not host substitutions. Compare independently known events and labelled frames. Record actual commands/results; pending commands are not successful checks. If the documented entrypoint does not exist, report NOT_IMPLEMENTED and do not improvise a success result.
19: 
20: Stop conditions: Stop render track on unavailable binary or conflicting participant capture; do not fabricate rendered output. Request shared-contract changes via integrator.
21: 
22: References: [CONTRACTS.md](../../../docs/CONTRACTS.md) [ARCHITECTURE.md](../../../docs/ARCHITECTURE.md) [EVALUATION.md](../../../docs/EVALUATION.md) [tasks/02B.md](../../../docs/tasks/02B.md)
23: 
24: ## Authorized production revamp
25: 
26: Read [production status and commands](../../../reports/blender-revamp/DELIVERY.md) before resuming. Preserve archived candidates and source snapshots; build into a new directory. Default extraction is240Hz and playback30fps on the same seconds clock. Bullet solver resolution and extraction rate are independent. Calibrate the declared backend on isolated controls before judging production motion; a successful process exit or replay does not close physical or perceptual gates.
27: 
28: Use `modules.blender.selection` for exact active or explicit staged identity. Silent physical supports never own a musical motif. Canonical0.1 remains unchanged; roles, production evidence, features and playback policy are versioned supplements. Bind their exact bytes/hashes through preparation and approval. Keep full original music and a separate scene-duration excerpt with10ms final fade; no adaptive composition in this DAG.
29: 
30: Pinned Blender MCP is for bounded loopback inspection/scratch experiments only; see [MCP evidence](../../../reports/blender-revamp/MCP.md). Capture accepted interactive changes in generation source and invalidate derived evidence. CLI generation remains independent. Full decoding and still inspection do not certify continuous motion or human audition. Native hero calibration currently fails; do not activate it or render final hero/control production until that prerequisite passes under an explicitly authorized repair scope.
```

## `modules/blender/README.md` lines 1–12

SHA-256: `f0ee3217bee4a0550790c5baffe4959572b78db9453c45502f231a2c13e5ee6e`

```text
1: # Evaluated scene generator — Phase 2B
2: 
3: Ten trusted, separately runnable Blender scripts build original abstract choreography and export canonical 0.1 scene records. **Synthetic generated animation**, not measured rigid-body physics. The module does not contain audio, model calls, participant capture or application UI.
4: 
5: Use Blender **5.2.1 LTS**, the actually tested version. It runs in Blender's Python, with no new packages. A user-supplied macOS image was temporarily mounted read-only for this phase; it is not a persistent installation. Set `BLENDER_BIN` to an available, verified binary for later runs. Missing Blender blocks generation, not reading existing bundles or keyboard/replay music workflows.
6: 
7: ```sh
8: "$BLENDER_BIN" --background --factory-startup --python-exit-code 1 --threads 2 --python modules/blender/scenes/01_head_on.py -- --seed 42 --out artifacts/blender/head-on --export-only
9: python -m modules.blender.batch --blender "$BLENDER_BIN" --out artifacts/blender/new-smoke --duration 3 --fps 8 --timeout 120
10: python -m modules.blender.batch --blender "$BLENDER_BIN" --out artifacts/blender/new-hero --recipe 10_projectile_tower --fps 8 --render --timeout 600
11: python -m modules.blender.batch --blender "$BLENDER_BIN" --out artifacts/blender/new-miss --recipe 10_projectile_tower --variant near_miss --fps 8 --render --timeout 600
12: PYTHONPATH=.:src python -m modules.blender.validate artifacts/blender/new-hero/10_projectile_tower-default
```

## `modules/blender/production/scenes.py` lines 12–45

SHA-256: `9e922996963a9ed1abef2bb8b016d0c27443bc73e0a408a94e151b47a33f01ed`

```text
12:     rid, variant = config['recipe'], config['variant']
13:     controls = ('control_drop', 'control_bounce', 'control_stack', 'control_rotated', 'control_fast', 'control_transfer', 'control_analytic_bounce', 'control_driven')
14:     if rid not in (*IDS, *controls):
15:         raise ValueError('unknown trusted recipe')
16:     hz, seconds = config['physics_hz'], config['seconds']
17:     parameters = config.get('parameters', {})
18:     bpy.ops.object.select_all(action='SELECT')
19:     bpy.ops.object.delete(use_global=False)
20:     scene = bpy.context.scene
21:     scene.unit_settings.system = 'METRIC'
22:     scene.unit_settings.scale_length = 1
23:     scene.gravity = (0, 0, -9.81)
24:     scene.render.fps = hz
25:     scene.render.fps_base = 1
26:     scene.frame_start, scene.frame_end = 1, round(seconds*hz)+1
27:     scene.render.engine = 'BLENDER_EEVEE'
28:     scene.render.resolution_x, scene.render.resolution_y = 640, 360
29:     scene.render.resolution_percentage = 100
30:     scene.render.image_settings.file_format = 'PNG'
31:     scene.world.color = (.22, .22, .22)
32:     scene.view_settings.view_transform = 'AgX'
33:     materials = {}
34:     palette = {'floor': (.48, .45, .40), 'metal': (.035, .049, .055),
35:                'ball': (.027, .245, .27), 'wood': (.57, .29, .08),
36:                'wood2': (.72, .43, .15), 'wood3': (.40, .19, .055),
37:                'neutral': (.45, .45, .45), 'stripe': (.78, .73, .62)}
38:     for name, color in palette.items():
39:         mat = bpy.data.materials.new('diagnostic_neutral' if name == 'neutral' else name)
40:         mat.diffuse_color = (*color, 1)
41:         mat.use_nodes = True
42:         bsdf = mat.node_tree.nodes.get('Principled BSDF')
43:         bsdf.inputs['Base Color'].default_value = (*color, 1)
44:         bsdf.inputs['Roughness'].default_value = .7 if name == 'floor' else .52
45:         materials[name] = mat
```

## `modules/blender/production/scenes.py` lines 50–85

SHA-256: `9e922996963a9ed1abef2bb8b016d0c27443bc73e0a408a94e151b47a33f01ed`

```text
50:     def add(name, position, *, half=None, radius=None, mode='passive', scored=False,
51:             role='support', material='metal', mass=1, friction=.7, restitution=.12,
52:             rotation=(0, 0, 0), angular_damping=.35):
53:         oid = rid+':'+name
54:         restitution = parameters.get('native_restitution', restitution)
55:         if radius is not None:
56:             bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=16, radius=radius, location=position)
57:         else:
58:             bpy.ops.mesh.primitive_cube_add(size=2, location=position)
59:             bpy.context.object.scale = half
60:             bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
61:         obj = bpy.context.object
62:         obj.name = oid
63:         obj.rotation_euler = rotation
64:         obj.data.materials.append(materials[material])
65:         obj['scenescore_id'] = oid
66:         obj['scored'] = scored
67:         obj['sonic_identity_id'] = 'voice:'+name if scored else 'silent:'+name
68:         if radius:
69:             for poly in obj.data.polygons:
70:                 poly.use_smooth = True
71:         # Shading bevel is smaller than the frozen contact tolerance.
72:         elif material.startswith('wood') or material == 'metal':
73:             bevel = obj.modifiers.new('subtle_edge', 'BEVEL')
74:             bevel.width = min(.002, min(half)*.005)
75:             bevel.segments = 2
76:         bpy.ops.rigidbody.object_add()
77:         rb = obj.rigid_body
78:         rb.type = 'ACTIVE' if mode in ('dynamic', 'driven') else 'PASSIVE'
79:         rb.kinematic = mode == 'driven'
80:         rb.collision_shape = 'SPHERE' if radius else 'BOX'
81:         rb.use_margin = True
82:         rb.collision_margin = .0005
83:         rb.mass, rb.friction, rb.restitution = mass, friction, restitution
84:         rb.linear_damping, rb.angular_damping = 0, angular_damping
85:         rb.use_deactivation = False
```

## `modules/blender/production/scenes.py` lines 117–147

SHA-256: `9e922996963a9ed1abef2bb8b016d0c27443bc73e0a408a94e151b47a33f01ed`

```text
117:     def fixed_obstacle_mechanics(ball, restitution, friction=.35):
118:         from .analytic import simulate_sphere
119:         bpy.context.view_layer.update()
120:         obstacles = []
121:         obstacle_ids = []
122:         for spec in specs:
123:             if spec['mode'] != 'passive':
124:                 continue
125:             obj = bpy.data.objects[spec['object_id']]
126:             q = obj.matrix_world.to_quaternion()
127:             obstacles.append({**spec, 'position_m': list(obj.matrix_world.translation),
128:                               'quaternion_xyzw': [q.x,q.y,q.z,q.w]})
129:             obstacle_ids.append(spec['object_id'])
130:         spec = next(s for s in specs if s['object_id'] == ball.name)
131:         track = simulate_sphere(list(ball.location), [0,0,0], spec['radius_m'], obstacles, seconds,
132:                                 hz=hz, restitution=restitution, friction=friction,
133:                                 substeps=parameters.get('analytic_substeps',32), rolling_resistance=.02)
134:         # The animation is computed mechanics, never a hand-authored outcome.
135:         # Bullet cannot interact with this actor; its fixed obstacles are above.
136:         ball.rigid_body.kinematic = True
137:         ball.rotation_mode = 'QUATERNION'
138:         for row in track:
139:             ball.location = row['position_m']
140:             q = row['quaternion_xyzw']
141:             ball.rotation_quaternion = (q[3],*q[:3])
142:             ball.keyframe_insert(data_path='location',frame=1+row['tick'])
143:             ball.keyframe_insert(data_path='rotation_quaternion',frame=1+row['tick'])
144:         linear_keys(ball)
145:         spec.update(motion_backend='fixed-obb-sphere-mechanics-1',restitution=restitution,
146:                     friction=friction,rolling_resistance=.02,linear_damping=0,angular_damping=0,
147:                     blender_kinematic_replay=True)
```

## `modules/blender/production/scenes.py` lines 250–260

SHA-256: `9e922996963a9ed1abef2bb8b016d0c27443bc73e0a408a94e151b47a33f01ed`

```text
250:     elif rid == '05_bouncing_staircase':
251:         for i in range(4):
252:             h=1.6-i*.4
253:             step=add('step-'+str(i),(-2.5+i*1.2,0,h/2),half=(.58,.8,h/2),scored=True,role='platform',material='wood')
254:             next(s for s in specs if s['object_id']==step.name)['restitution']=.8
255:         add('start-ramp',(-3.4,0,2.1),half=(.85,.5,.06),rotation=(0,.35,0))
256:         ramp_legs('start-ramp',(-3.4,0,2.1),.85,.5,.06,.35)
257:         ball=add('bouncer',(-3.9,0,2.63),radius=.25,mode='dynamic',scored=True,role='projectile',material='ball',restitution=.6,angular_damping=.6)
258:         next(s for s in specs if s['object_id']==rid+':floor')['restitution']=.8
259:         fixed_obstacle_mechanics(ball,.6)
260:         cases.append({'kind':'supported_rest','object_id':rid+':step-0','start_s':0,'end_s':seconds})
```

## `modules/blender/production/scenes.py` lines 319–357

SHA-256: `9e922996963a9ed1abef2bb8b016d0c27443bc73e0a408a94e151b47a33f01ed`

```text
319:     world=scene.rigidbody_world
320:     world.substeps_per_frame=config['solver_substeps']
321:     world.solver_iterations=config['solver_iterations']
322:     world.time_scale=1
323:     world.use_split_impulse=parameters.get('split_impulse',False)
324:     world.point_cache.frame_start=1
325:     world.point_cache.frame_end=round(seconds*hz)+1
326:     # Broad floor markings establish the lane without becoming interaction actors.
327:     for y in (-1.7,1.7):
328:         decor('lane-'+str(y),(0,y,.001), (4.7,.018,.001), 'stripe')
329:     for name,location,focus,ortho in [('beauty',(8,-14,8),(-.2,0,.65),None),
330:                                       ('side',(0,-16,3.2),(0,0,.8),13),
331:                                       ('top',(0,0,18),(0,0,0),14)]:
332:         bpy.ops.object.camera_add(location=location)
333:         camera=bpy.context.object
334:         camera.name='camera_'+name
335:         camera.rotation_euler=(Vector(focus)-camera.location).to_track_quat('-Z','Y').to_euler()
336:         camera.data.lens=44 if rid == '03_passing_ascent' and name == 'beauty' else 48
337:         if ortho:
338:             camera.data.type='ORTHO'
339:             camera.data.ortho_scale=ortho
340:     scene.camera=bpy.data.objects['camera_beauty']
341:     for location,power,size in [((-3,-5,9),1800,7),((4,4,6),1100,6)]:
342:         bpy.ops.object.light_add(type='AREA',location=location)
343:         light=bpy.context.object
344:         light.data.energy,light.data.size=power,size
345:         light.rotation_euler=(Vector((0,0,.5))-light.location).to_track_quat('-Z','Y').to_euler()
346:     scene.frame_set(1)
347:     return {'recipe_id':rid,'variant':variant,'seed':config['seed'],'physics_hz':hz,'render_fps':30,
348:             'duration_s':seconds,'gravity_m_s2':[0,0,-9.81],
349:             'solver':{'substeps_per_frame':config['solver_substeps'],'solver_iterations':config['solver_iterations'],
350:                       'use_split_impulse':world.use_split_impulse},
351:             'objects':specs,'validation_cases':cases,
352:             'require_settled_end':rid not in controls,
353:             'motion_mode':'fixed-obb-sphere-mechanics-1' if analytic_tracks else 'Bullet dynamics with explicitly driven mechanisms',
354:             'mechanics':{'model_version':'fixed-obb-sphere-mechanics-1','substeps':parameters.get('analytic_substeps',32),
355:                          'rolling_resistance':.02,'scope':'one sphere and fixed oriented boxes'} if analytic_tracks else None,
356:             '_analytic_tracks':analytic_tracks,
357:             'source_mode':'synthetic','approval':None}
```

## `modules/blender/production/driver.py` lines 217–255

SHA-256: `e5273b3509658a20fc951b2b60863e2bfd8d02f6c96f7667ad1961fc43b0a7f7`

```text
217: def render(args):
218:     import bpy
219:     bpy.ops.wm.open_mainfile(filepath=str(args.out/'scene.blend'), load_ui=False, use_scripts=False)
220:     scene = bpy.context.scene
221:     prod = read(args.out/'production.json')
222:     width, height = (1920, 1080) if args.profile == 'final' else (640, 360)
223:     scene.render.resolution_x, scene.render.resolution_y = width, height
224:     scene.render.resolution_percentage = 100
225:     scene.camera = bpy.data.objects['camera_'+args.camera]
226:     if args.profile == 'diagnostic':
227:         neutral=bpy.data.materials.get('diagnostic_neutral') or bpy.data.materials.new('diagnostic_neutral')
228:         neutral.use_nodes=True
229:         bsdf=neutral.node_tree.nodes.get('Principled BSDF')
230:         bsdf.inputs['Base Color'].default_value=(.45,.45,.45,1)
231:         bsdf.inputs['Roughness'].default_value=.7
232:         scene.view_layers[0].material_override = neutral
233:     if hasattr(scene,'eevee') and hasattr(scene.eevee,'taa_render_samples'):
234:         scene.eevee.taa_render_samples=64 if args.profile=='final' else 16
235:     scene.render.image_settings.file_format = 'PNG'
236:     scene.render.image_settings.color_mode = 'RGB'
237:     total = round(prod['duration_s']*30)
238:     scene.frame_start, scene.frame_end = args.first, min(args.last or total, total)
239:     target = args.out/'renders'/args.profile/args.camera
240:     target.mkdir(parents=True, exist_ok=True)
241:     scene.render.filepath = str(target/'frame_######')
242:     bpy.ops.render.render(animation=True)
243:     expected = {f'frame_{frame:06d}.png' for frame in range(1, total+1)}
244:     if expected.issubset({p.name for p in target.glob('*.png')}):
245:         video = target/'video.mp4'
246:         cmd = ['/opt/homebrew/bin/ffmpeg', '-v', 'error', '-nostdin', '-y', '-framerate', '30',
247:                '-start_number', '1', '-i', str(target/'frame_%06d.png'), '-frames:v', str(total),
248:                '-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(video)]
249:         encoded = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
250:         dump(target/'render.json', {'profile': args.profile, 'camera': args.camera, 'command': cmd,
251:              'returncode': encoded.returncode, 'stderr': encoded.stderr, 'frame_count': total,
252:              'source_hash': digest(args.out/'scene.blend'), 'states_hash': digest(args.out/'physics_states.jsonl'),
253:              'width': width, 'height': height, 'fps': 30,
254:              'renderer_code_hashes':source_hashes(),
255:              'video_hash': digest(video) if encoded.returncode == 0 else None})
```

## `modules/blender/production/validation.py` lines 416–426

SHA-256: `0a952f538270864a385a0deaefe19c9f236c2286cc3799bdc91809205598876c`

```text
416: def validate_candidate(directory: str | Path, *, check_calibration: bool = True) -> dict:
417:     root = Path(directory).resolve()
418:     result = {"version": VERSION, "candidate": str(root), "status": "NOT_RUN", "gates": {}, "metrics": {},
419:               "issues": [], "tolerance_policy": TOLERANCE_POLICY.copy(), "limitations": [
420:                   "Sampled evaluated solids; no global continuous-time guarantee.",
421:                   "Copied metadata does not establish Blender provenance; fresh asset evidence is a separate gate.",
422:                   "No motion-perception, soundtrack audition or human approval is implied."]}
423:     gates, issues, metrics = result["gates"], result["issues"], result["metrics"]
424:     for name in ["asset_integrity", "geometric_contact", "physical_motion", "fresh_process_replay",
425:                  "solver_calibration", "rendered_temporal", "perceptual_story_appearance"]:
426:         gates[name] = {"status": "NOT_RUN"}
```

## `modules/blender/production/validation.py` lines 519–524

SHA-256: `0a952f538270864a385a0deaefe19c9f236c2286cc3799bdc91809205598876c`

```text
519:         gates[issue["gate"]]["status"] = "FAILED"
520:     physical_names = ["asset_integrity", "geometric_contact", "physical_motion", "fresh_process_replay", "solver_calibration"]
521:     statuses = [gates[name]["status"] for name in physical_names]
522:     result["status"] = "FAILED" if "FAILED" in statuses else "PASSED" if all(s == "PASSED" for s in statuses) else "NOT_RUN"
523:     gates["physical_candidate"] = {"status": result["status"], "requires": physical_names}
524:     return result
```

## `reports/blender-revamp/DELIVERY.md` lines 1–40

SHA-256: `899cf25acb3a68612bd7c1db5f7f70f746f8ce3a998a47185818d42a08c83df9`

```text
1: # Blender production revamp — implemented, partially verified, blocked for final hero
2: 
3: The patched DAG was executed through source implementation, real Blender generation/baking/fresh playback verification, diagnostic and scoped beauty rendering, independent review/repair, and a runnable staged integration. **The complete revamp is not accepted.** Native Bullet calibration exhausted three bounded repairs; required final hero/control production and full native-motion perception remain blocked/unverified. All delivered integration bundles have `approval:null`. The active historical hero selection is unchanged.
4: 
5: ## Actual delivery
6: 
7: | Item | Exact artifact |
8: |---|---|
9: | Final eight-second draft, light swing | [swing-DRAFT.mp4](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/integration/final/swing-DRAFT.mp4) |
10: | Same scene, sparse brush / straight rag | [ballad-DRAFT.mp4](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/integration/final/ballad-DRAFT.mp4), [rag-DRAFT.mp4](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/integration/final/rag-DRAFT.mp4) |
11: | Final lossless mix, four stems and original editable event report per groove | [final-exports](/Users/agent/Desktop/SceneScore/output/playwright/blender-revamp/final-exports) |
12: | Exact explicit staged selection | [staircase-selection.json](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/review/staircase-selection.json) |
13: | Simulation and playback Blender files | [simulation.blend](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/review/05_bouncing_staircase-32/simulation.blend), [scene.blend](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/review/05_bouncing_staircase-32/scene.blend) |
14: | Cache/replay/source lineage | [candidate directory](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/review/05_bouncing_staircase-32): embedded saved point cache, mechanics_states.json, 1,921 evaluated 240 Hz rows, bake-reopen.json, replay_states.jsonl, replay_validation.json and generation_source/ |
15: | Authoritative motion/music handoff | [handoff.json](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/review/05_bouncing_staircase-32/handoff.json), [features.jsonl](/Users/agent/Desktop/SceneScore/artifacts/blender/revamp/review/05_bouncing_staircase-32/features.jsonl), handoff_hashes.json |
16: | All ten recipes, hero controls, neutral/beauty videos and source identities | [catalogue.json](/Users/agent/Desktop/SceneScore/reports/blender-revamp/catalogue.json) |
17: | Before-revamp failure evidence, unchanged | [original-DRAFT.mp4](/Users/agent/Desktop/SceneScore/blender_revamp/scenescore_blender_revamp_patched/evidence/original-DRAFT.mp4) |
18: 
19: Final exports are labelled **“Draft · existing score excerpt · adaptive scoring pending.”** All three retain the complete original score: 304 / 244 / 280 events, with separate 95 / 79 / 89 event projections onto `[0,8)`. Eight Foley onsets use independently certified contact times. Each delivered video has 240 frames at 30 fps; every lossless stereo file has 384,000 samples at 48 kHz (1,600 samples/frame). A shared 10 ms output fade ends mix and stems at zero. Original event durations, composition, tempo and editable symbolic material are preserved.
20: 
21: Use only `integration/final/` and `final-exports/` for current exports. Earlier export copies were invalidated after retained Playwright download handlers overwrote groove destinations. Those artifacts and their failed lineage remain preserved with [export-invalidation.json](export-invalidation.json). A fresh session recreated three distinct bundles; [delivery-audit-final.json](delivery-audit-final.json) rechecks their identities, complete score events, exact contact/Foley mapping, aligned WAVs and final samples. A duplicate-bundle negative check now fails closed.
22: 
23: ## Gate results
24: 
25: | Gate | Result and evidence |
26: |---|---|
27: | Scope / immutable inputs / ownership | PASSED: all 30 patched-pack hashes still match; canonical 0.1 and historical selection unchanged. Separate worktrees and disjoint ownership were used. [final-preservation.json](final-preservation.json). |
28: | Reproducible production stages | IMPLEMENTED: separate build, bake, replay, fresh-process verification, validation, export and render. Actual saved assets and job receipts exist for every catalogue entry. Fresh playback was checked at every evaluated tick; this is not a claim of a second clean checkout rebake of the entire hero pipeline. |
29: | Native Bullet material/transfer calibration | FAILED after three repairs. Final 50→100 substep trajectory difference **32.570 mm**, limit 5 mm; finer outgoing relative speed **0.163740 m/s**, limit 0.1. [native-calibration-final.json](native-calibration-final.json). No criterion was relaxed. |
30: | Hero, matched miss, launch-disabled control | Seven-second actual Blender simulations, supported endings, fresh replay and complete neutral movies exist. Physical acceptance remains NOT_RUN because native calibration fails. No 1920×1080 final hero/control was rendered or made active. |
31: | Scoped positive catalogue | Numerical PASSED for lift, orbital sculpture, staircase and breathing crowd. Staircase is explicitly `fixed-obb-sphere-mechanics-1`, one sphere against fixed OBBs; the other three are prescribed supported mechanisms. These scopes do not certify native multi-body dynamics. Current lift is `review-camera-repair-2/03_passing_ascent`. |
32: | Remaining catalogue | Head-on, near-miss twins, sliding contact, shape contrast, domino cascade and projectile tower have native 30 fps neutral diagnostics and fresh replay; native physical acceptance remains blocked. |
33: | Rendering / cadence | Twelve current neutral clips (ten recipes plus extra hero controls), four beauty previews at 640×360; recoverable PNG sequences retained. Every current clip passed full decoding, PTS/count and source-motion cadence checks. [catalogue.json](catalogue.json). |
34: | Negative controls | Nine analytical positives and nine negatives classified correctly. Eight copied-sidecar mutations detected. Separately, two actual-scene baselines and five actual Blender faults produced expected results across 28 Blender jobs. Causal release-impulse, actual stale-cache and fabricated-miss scene mutations remain incomplete. [physics-review-addendum.md](../../docs/requests/08/physics-review-addendum.md). |
35: | Contact / handoff | Eight independently fitted contact onsets, one supported ramp release and one dynamic settling marker. Release 1.145446080 s, uncertainty 1/240 s, confirmation 1.179166667 s. Twenty contact intervals and two other release transitions remain unverified; coverage is explicitly incomplete. No impulse is invented. |
36: | Selection / API / approval | Exact staged selection, source/video/role/feature/policy hashes verified. Actual API summary and event reads pass; default hero remains legacy. Six regenerated legacy bundles preserve all compared baseline scene/music/plan fields; public/build assets now explicitly label them as legacy choreography. Bound policy/window removal rejects; silent supports cannot own motifs or automatic focus. [api-final.json](api-final.json), [runtime review](../../docs/requests/08/runtime-review.md). |
37: | Browser / software AV | Actual complete playback, seek to 2 s/resume, and final repaired-build playback passed. P95 absolute software drift: **29.73 ms / 26.13 ms / 8.50 ms**, target 50 ms. Final take observed 239 presentation callbacks and scheduled 95 events. PTS-based measurements and audio anchors are retained; missing callbacks are not manufactured. [integration-timing.json](integration-timing.json). |
38: | Offline export / mux | Three distinct actual browser OfflineAudioContext exports; all five WAVs align per bundle, mix equals summed stems within 2 PCM units. Three final muxes decode 240 frames and 384,000 audio samples, starting at PTS zero. [delivery-audit-final.json](delivery-audit-final.json), [final-mux-decoding.json](final-mux-decoding.json). |
39: | MCP | Pinned upstream `5f8ddaf6e987c4aa0c3467fcc548838b28f64477`, addon 1.6 / server 1.9.1 / protocol 5. Loopback inspection, viewport capture and scratch create/inspect/delete restoration passed; final blend unchanged. Upstream get_addon_status has a missing-module error. Project/RAM setup only, no global preference install. [MCP.md](MCP.md). |
40: | Visual / causal / human | Model still inspection led to visible supports, clearance and camera repairs captured in generation source. Complete native-motion perception and audio audition are UNVERIFIED. Human approval, physical AV latency and hardware validation remain pending. No overall animation or product-completion claim. |
```

## `reports/blender-revamp/MCP.md` lines 1–40

SHA-256: `a895139e453187d96d4a58e70fb045e3f1f90e7f5387795a5d9bb23504372831`

```text
1: # Actual project-scoped MCP smoke
2: 
3: Pinned upstream revision: `5f8ddaf6e987c4aa0c3467fcc548838b28f64477`.
4: Addon SHA-256: `f43469c8518c7021e0060e32cfe52e3beb126b0f62fbae7293106642a3ebda89`.
5: Server 1.9.1, addon 1.6, protocol 5; handshake observed in real MCP STDIO logs.
6: The addon is loaded only in an owned GUI session by the checked-in bootstrap;
7: it is not installed into the user's global Blender addon directory. Preferences
8: are not saved. Project server dependencies are frozen alongside the client.
9: 
10: Actual second smoke: get_scene_info, create cube via execute_blender_code,
11: get_object_info, delete cube, get_scene_info and get_viewport_screenshot completed.
12: Initial/final scene each had the same three factory objects. The inspected cube
13: was 0.1 m at (0,0,3), then absent. Actual screenshot inspected by coordinator.
14: Evidence: `artifacts/blender/revamp/mcp/smoke-2/calls.json` and PNG alongside it.
15: 
16: Separate upstream limitation: get_addon_status returned an error string,
17: `No module named blender_mcp.config`, while its MCP isError flag was false.
18: Its protocol handshake succeeded; the higher-level status call did not pass.
19: The pinned source's telemetry constructor imports that missing module. The task
20: does not patch upstream telemetry to manufacture a clean status. Server opt-out
21: environment flags are set; addon telemetry preference is explicitly false and
22: asserted before the final loopback listener starts. Asset integrations are off.
23: 
24: First attempt failed because client filename inspect.py shadowed Python's inspect
25: module and upstream auto-start occupied the owned socket. The client was renamed
26: and the bootstrap stops the upstream-owned auto-start listener before starting
27: the explicit 127.0.0.1 listener. Original failed job evidence is retained.
28: 
29: This smoke is tooling evidence, not production animation or perceptual approval.
30: 
31: ## Final staged-candidate inspection
32: 
33: `artifacts/blender/revamp/mcp/final-inspection/client/calls.json` records actual
34: get_scene_info, read-only object/frame inspection and viewport capture for the
35: final staircase blend. The viewport PNG was inspected. No interactive scene
36: change was accepted or saved; final scene.blend SHA remains
37: 854e00a2410ceab0aab690207a4649ad9c66c1255f7567cd954988ede1c6a30d.
38: Owned GUI PGID46186 was intentionally stopped after inspection; final process-table
39: audit confirms all recorded job groups absent. The upstream addon-status import
40: error remains; inspection/screenshot success does not turn it into a passing call.
```

## `docs/blender-revamp/RESTITUTION-DIAGNOSTIC.md` lines 1–18

SHA-256: `b835f280ec0907a7cdd125d0dbeee62baf9f38d81df39c7a1f23b2f515bcd397`

```text
1: # Restitution diagnostic — installed Blender 5.2.1 LTS
2: 
3: Status: **cause strongly evidenced; no supported Blender RNA configuration fix verified**.
4: No production files, acceptance criteria, vendor source or caches were changed.
5: Investigation began 2026-09-12 17:58 UTC and was bounded to ten minutes.
6: 
7: ## Finding
8: 
9: The missing bounce is consistent with Bullet solving a contact while the sphere
10: still has a positive geometric gap. The solver subtracts `gap / timestep` from
11: the restitution velocity target. Increasing simulation frequency changes which
12: positive gap is encountered first, so a stored restitution of 1 does not preserve
13: the measured outgoing speed in this setup. This explanation predicts both the
14: 480 Hz and 960 Hz results to the precision of the exported states.
15: 
16: Setting restitution after `bpy.ops.rigidbody.object_add()` is not an evidenced
17: initialization bug: the installed revision's RNA setter updates both the stored
18: value and an existing physics body. Body creation copies the stored value into a
```

## `docs/blender-revamp/RESTITUTION-DIAGNOSTIC.md` lines 96–133

SHA-256: `b835f280ec0907a7cdd125d0dbeee62baf9f38d81df39c7a1f23b2f515bcd397`

```text
96: physical and units-invariance gates; this diagnostic did not perform that trial.
97: 
98: ## Minimal actionable disposition
99: 
100: Do not spend another repair on resetting restitution, raising iteration count,
101: or assuming that more substeps or unit scaling repairs this contact behavior.
102: Keep the current controls failed. Preserve the animation clock and metre-based
103: acceptance tolerances.
104: 
105: The relevant low-level contact-processing and solver thresholds are absent from
106: the installed `RigidBodyWorld` and `RigidBodyObject` RNA inventories. No supported
107: configuration-only fix was established in this bounded investigation. A change
108: to contact handling, collision representation or backend needs independently
109: reviewed implementation and fresh controls; it cannot be claimed equivalent from
110: flags alone. No ctypes access, unreviewed vendor patch or replacement simulator
111: was attempted. This is an honest production blocker until a candidate passes the
112: existing gates, not permission to relax them.
113: 
114: ## Authorized follow-up: transparent fixed-obstacle sphere mechanics
115: 
116: A later coordinator assignment authorized a scoped alternative for the staircase
117: and isolated high-bounce control. `modules/blender/production/analytic.py` now
118: implements `simulate_sphere(...)` as **fixed-obb-sphere-mechanics-1**. This does
119: not change or repair native Bullet, and the original unsupported elastic-Bullet
120: control remains failed.
121: 
122: The function accepts an SI sphere state, fixed oriented boxes and a duration
123: that has an integral number of output ticks. It returns tick-zero through the
124: exact endpoint, including position/velocity, normalized orientation quaternion,
125: world angular velocity and contact indices. The default output rate is 240 Hz
126: with 32 constant internal substeps; 64 is the independent resolution comparison.
127: All bodies are represented in metres and seconds. The fixed-obstacle equations
128: use unit mass because mass cancels from the sphere's motion in this model.
129: 
130: Free-flight segments integrate constant gravity exactly. Newly crossed box
131: surfaces are located by bisection on that segment before an impulse is applied.
132: Sphere/OBB distance and normals include box rotation and contained centres; deep
133: initial overlap is rejected instead of corrected by a teleport. Motion that
```

## `.codex/config.toml` lines 1–5

SHA-256: `77776b1284a11d5f729c3d5cd23311726f2ca7254146e5f4360b72e45bfa68e9`

```text
1: [mcp_servers.blender]
2: command = "/Users/agent/Desktop/SceneScore/artifacts/tools/blender-mcp-env/bin/blender-mcp"
3: tool_timeout_sec = 30
4: env = { BLENDER_HOST = "127.0.0.1", BLENDER_PORT = "9876", BLENDER_MCP_SAFE_MODE = "1", DISABLE_TELEMETRY = "true" }
5: enabled_tools = ["get_addon_status", "get_scene_info", "get_object_info", "get_viewport_screenshot", "execute_blender_code"]
```

## `tools/blender_mcp/client.py` lines 1–57

SHA-256: `78f5a78b036721d969745e1f168df55e4878d58d14e5f9a57ce08dcbab8be37e`

```text
1: """Bounded real MCP client for the project-scoped pinned Blender server."""
2: import argparse
3: import asyncio
4: import base64
5: import json
6: import os
7: from pathlib import Path
8: 
9: from mcp import ClientSession, StdioServerParameters
10: from mcp.client.stdio import stdio_client
11: 
12: ROOT = Path(__file__).resolve().parents[2]
13: 
14: 
15: async def main(args):
16:     args.out.mkdir(parents=True, exist_ok=True)
17:     env = dict(os.environ, BLENDER_HOST='127.0.0.1', BLENDER_PORT='9876',
18:                BLENDER_MCP_SAFE_MODE='1', DISABLE_TELEMETRY='true')
19:     params = StdioServerParameters(command=str(ROOT/'artifacts/tools/blender-mcp-env/bin/blender-mcp'), env=env)
20:     results = []
21:     async with stdio_client(params) as (read, write):
22:         async with ClientSession(read, write) as session:
23:             await session.initialize()
24:             available = await session.list_tools()
25:             (args.out/'available-tools.json').write_text(json.dumps([t.model_dump() for t in available.tools], indent=2))
26:             calls = [('get_addon_status', {}), ('get_scene_info', {'user_prompt': args.prompt})]
27:             if args.smoke:
28:                 calls += [
29:                     ('execute_blender_code', {'code': 'import bpy\nbpy.ops.mesh.primitive_cube_add(size=0.1, location=(0,0,3))\nbpy.context.object.name="SCENESCORE_MCP_SCRATCH"', 'user_prompt': args.prompt}),
30:                     ('get_object_info', {'object_name': 'SCENESCORE_MCP_SCRATCH', 'user_prompt': args.prompt}),
31:                     ('execute_blender_code', {'code': 'import bpy\nbpy.data.objects.remove(bpy.data.objects["SCENESCORE_MCP_SCRATCH"], do_unlink=True)', 'user_prompt': args.prompt}),
32:                     ('get_scene_info', {'user_prompt': args.prompt}),
33:                 ]
34:             if args.code:
35:                 calls.append(('execute_blender_code', {'code': args.code.read_text(), 'user_prompt': args.prompt}))
36:             calls.append(('get_viewport_screenshot', {'max_size': 1280, 'user_prompt': args.prompt}))
37:             for index, (name, arguments) in enumerate(calls):
38:                 response = await asyncio.wait_for(session.call_tool(name, arguments), 30)
39:                 payload = response.model_dump(mode='json')
40:                 for block in payload.get('content', []):
41:                     if block.get('type') == 'image':
42:                         target = args.out/f'{index:02d}-{name}.png'
43:                         target.write_bytes(base64.b64decode(block.pop('data')))
44:                         block['local_image'] = str(target)
45:                 results.append({'tool': name, 'arguments': arguments, 'response': payload})
46:                 (args.out/'calls.json').write_text(json.dumps(results, indent=2))
47:                 print(json.dumps({'tool': name, 'isError': response.isError}), flush=True)
48:     return 0
49: 
50: 
51: if __name__ == '__main__':
52:     parser = argparse.ArgumentParser()
53:     parser.add_argument('--out', type=Path, required=True)
54:     parser.add_argument('--smoke', action='store_true')
55:     parser.add_argument('--code', type=Path)
56:     parser.add_argument('--prompt', default='Use Blender CLI/Python for reproducible production and the requested blender-mcp for bounded interactive inspection.')
57:     raise SystemExit(asyncio.run(main(parser.parse_args())))
```

## `blender_exemplar_search_kit/README.md` lines 1–26

SHA-256: `b44132348370b13726372cd0843722c119a1ef686e9ce6a5191058ea9b9a9377`

```text
1: # Blender physics exemplar search kit
2: 
3: Prepared 13 September 2026. This is a discovery and curation starter kit, not a
4: prevalidated video dataset or a finished Blender skill. No third-party videos or
5: project files are included. The seed records have metadata/creator-page checks,
6: not frame-level event verification. No API credentials are bundled.
7: 
8: ## Recommended workflow
9: 
10: Search by mechanism -> inspect creator/source links -> screen a continuous shot
11: -> obtain an authorized master or render from a licensed project -> annotate
12: observable events -> create a tested reconstruction -> index by event and solver
13: family -> retrieve a small diverse set for each new animation request.
14: 
15: Keep discovery candidates, accepted visual references, and reconstruction-tested
16: examples separate. Do not collapse these into one confidence label.
17: 
18: ## Files
19: 
20: - `youtube_queries.txt`: 48 queries in eight mechanism/material families.
21: - `source_search_queries.txt`: web queries for locating project files and creators.
22: - `seed_candidates.jsonl`: the three user references plus five additional candidates.
23: - `collect_youtube.py`: read-only metadata search, channel expansion, and refresh.
24: - `screening_prompt.txt`: reusable video-screening instructions and JSON output.
25: - `exemplar_template.json`: a blank, explicitly unreviewed corpus record.
26: - `clip_commands.txt`: local FFmpeg preparation recipes; no video downloading.
```
